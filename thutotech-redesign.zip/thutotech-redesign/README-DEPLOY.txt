THUTOTECH WEBSITE REDESIGN — deploy in 2 minutes (GitHub web only)

1. Download/keep this folder's two items:
   - index.html        (the new home page — self-contained, no build)
   - assets/ folder    (logos: crest, Fundisa logo, product shields)

2. On GitHub: Reggie9102/Thuto-Technologies-PTY-LTD
   → Add file ▾ → Upload files
   → Drag index.html AND the assets folder together
   → index.html must show "will be replaced" warning; assets/ is created new
   → Commit directly to main

3. Wait ~60s. Check https://www.thutotech.co.za (hard refresh Ctrl+F5).
   Success signs: dark navy/gold hero, orbit of product shields,
   "Fresh from the foundry" releases list, 10 product cards with logos.

Notes:
- Future product cards (FundisaWork etc.): copy any <article class="card..."> block
  inside <div class="grid-p"> — keep the .card class, add acc-* for color,
  update hero stat data-num="10" to the new count and the "Ten products" heading.
- The floating TownshipMart button now appears only after you scroll past the hero.
